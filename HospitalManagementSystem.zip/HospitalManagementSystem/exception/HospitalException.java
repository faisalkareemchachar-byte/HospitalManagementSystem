// src/exception/HospitalException.java
package exception;

public class HospitalException extends Exception {
    public HospitalException(String message) {
        super(message);
    }
    
    public HospitalException(String message, Throwable cause) {
        super(message, cause);
    }
}