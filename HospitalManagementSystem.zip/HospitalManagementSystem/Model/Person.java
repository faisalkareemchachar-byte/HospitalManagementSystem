// src/model/Person.java
package model;

public abstract class Person {
    private String id;
    private String name;
    private String phone;
    
    public Person(String id, String name, String phone) {
        this.id = id;
        this.name = name;
        this.phone = phone;
    }
    
    // Getters and Setters (ENCAPSULATION)
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    
    // ABSTRACT METHOD for polymorphism
    public abstract String getRole();
    
    @Override
    public String toString() {
        return getRole() + ": " + name + " (ID: " + id + ", Phone: " + phone + ")";
    }
}