// src/model/Doctor.java
package model;

public class Doctor extends Person {
    private String specialization;
    private double consultationFee;
    
    public Doctor(String id, String name, String phone, String specialization, double consultationFee) {
        super(id, name, phone);
        this.specialization = specialization;
        this.consultationFee = consultationFee;
    }
    
    public String getSpecialization() { return specialization; }
    public void setSpecialization(String specialization) { this.specialization = specialization; }
    
    public double getConsultationFee() { return consultationFee; }
    public void setConsultationFee(double consultationFee) { this.consultationFee = consultationFee; }
    
    @Override
    public String getRole() {
        return "Doctor";
    }
    
    @Override
    public String toString() {
        return super.toString() + " | " + specialization + " | Fee: $" + consultationFee;
    }
}