// src/model/Patient.java
package model;

public class Patient extends Person {
    private String disease;
    private String bloodGroup;
    
    public Patient(String id, String name, String phone, String disease, String bloodGroup) {
        super(id, name, phone);
        this.disease = disease;
        this.bloodGroup = bloodGroup;
    }
    
    public String getDisease() { return disease; }
    public void setDisease(String disease) { this.disease = disease; }
    
    public String getBloodGroup() { return bloodGroup; }
    public void setBloodGroup(String bloodGroup) { this.bloodGroup = bloodGroup; }
    
    @Override
    public String getRole() {
        return "Patient";
    }
    
    @Override
    public String toString() {
        return super.toString() + " | Disease: " + disease + " | Blood: " + bloodGroup;
    }
}