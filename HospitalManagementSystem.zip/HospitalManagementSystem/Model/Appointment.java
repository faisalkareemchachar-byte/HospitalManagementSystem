// src/model/Appointment.java
package model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Appointment {
    private String appointmentId;
    private String patientId;
    private String doctorId;
    private LocalDateTime dateTime;
    private String status; // SCHEDULED, COMPLETED, CANCELLED
    
    public Appointment(String appointmentId, String patientId, String doctorId, LocalDateTime dateTime) {
        this.appointmentId = appointmentId;
        this.patientId = patientId;
        this.doctorId = doctorId;
        this.dateTime = dateTime;
        this.status = "SCHEDULED";
    }
    
    // Getters
    public String getAppointmentId() { return appointmentId; }
    public String getPatientId() { return patientId; }
    public String getDoctorId() { return doctorId; }
    public LocalDateTime getDateTime() { return dateTime; }
    public String getStatus() { return status; }
    
    public void cancel() { this.status = "CANCELLED"; }
    public void complete() { this.status = "COMPLETED"; }
    
    @Override
    public String toString() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        return "Appointment " + appointmentId + ": Patient " + patientId + 
               " with Doctor " + doctorId + " at " + dateTime.format(formatter) + 
               " [" + status + "]";
    }
}