// src/model/Staff.java
package model;

public class Staff extends Person {
    private String position;
    private double salary;
    
    public Staff(String id, String name, String phone, String position, double salary) {
        super(id, name, phone);
        this.position = position;
        this.salary = salary;
    }
    
    public String getPosition() { return position; }
    public void setPosition(String position) { this.position = position; }
    
    public double getSalary() { return salary; }
    public void setSalary(double salary) { this.salary = salary; }
    
    @Override
    public String getRole() {
        return "Staff";
    }
    
    @Override
    public String toString() {
        return super.toString() + " | " + position + " | Salary: $" + salary;
    }
}