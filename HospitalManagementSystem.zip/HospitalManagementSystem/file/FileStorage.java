// src/service/FileStorage.java
package service;

import java.io.*;
import java.util.*;

public class FileStorage {
    private static final String DATA_FILE = "data/hospital_data.txt";
    
    // Save data to file
    public static void saveData(Map<String, String> data) throws IOException {
        File directory = new File("data");
        if (!directory.exists()) {
            directory.mkdir();
        }
        
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(DATA_FILE))) {
            for (Map.Entry<String, String> entry : data.entrySet()) {
                writer.write(entry.getKey() + "=" + entry.getValue());
                writer.newLine();
            }
        }
    }
    
    // Load data from file
    public static Map<String, String> loadData() throws IOException {
        Map<String, String> data = new HashMap<>();
        File file = new File(DATA_FILE);
        
        if (!file.exists()) {
            return data;
        }
        
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split("=", 2);
                if (parts.length == 2) {
                    data.put(parts[0], parts[1]);
                }
            }
        }
        return data;
    }
}