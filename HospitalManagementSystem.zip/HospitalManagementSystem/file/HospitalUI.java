package ui;

import service.HospitalService;
import exception.HospitalException;
import model.*;
import java.util.*;

public class HospitalUI {
    private HospitalService service = new HospitalService();
    private Scanner scan = new Scanner(System.in);
    
    // MAIN MENU LOOP
    public void start() {
        while (true) {
            System.out.println("\n╔════════════════════╗");
            System.out.println("║ HOSPITAL SYSTEM    ║");
            System.out.println("╚════════════════════╝");
            System.out.println("1.Patients 2.Doctors 3.Appointments 4.Stats 5.Exit");
            System.out.print("Choice: ");
            
            try {
                switch (scan.nextInt()) {
                    case 1: patientMenu(); break;
                    case 2: doctorMenu(); break;
                    case 3: appointmentMenu(); break;
                    case 4: stats(); break;
                    case 5: System.out.println("Goodbye!"); return;
                }
            } catch(Exception e) { System.out.println("Error: " + e.getMessage()); scan.nextLine(); }
        }
    }
    
    // PATIENT MENU (Add, View, Search)
    private void patientMenu() throws HospitalException {
        while(true) {
            System.out.println("\n[PATIENTS] 1.Add 2.View 3.Search 4.Back");
            System.out.print("Choice: ");
            switch(scan.nextInt()) {
                case 1: // ADD PATIENT
                    scan.nextLine();
                    System.out.print("Name:"); String name = scan.nextLine();
                    System.out.print("Phone:"); String phone = scan.nextLine();
                    System.out.print("Disease:"); String disease = scan.nextLine();
                    System.out.println("✅ ID: " + service.addPatient(name, phone, disease));
                    break;
                case 2: // VIEW ALL
                    System.out.println("\n--- ALL PATIENTS ---");
                    for(Patient p : service.getAllPatients()) System.out.println(p);
                    break;
                case 3: // SEARCH
                    scan.nextLine();
                    System.out.print("Patient ID:");
                    System.out.println(service.findPatient(scan.nextLine()));
                    break;
                case 4: return;
            }
        }
    }
    
    // DOCTOR MENU (Add, View, Search)
    private void doctorMenu() throws HospitalException {
        while(true) {
            System.out.println("\n[DOCTORS] 1.Add 2.View 3.Search 4.Back");
            System.out.print("Choice: ");
            switch(scan.nextInt()) {
                case 1: // ADD DOCTOR
                    scan.nextLine();
                    System.out.print("Name:"); String n = scan.nextLine();
                    System.out.print("Phone:"); String p = scan.nextLine();
                    System.out.print("Specialization:"); String s = scan.nextLine();
                    System.out.print("Fee:$"); double f = scan.nextDouble();
                    System.out.println("✅ ID: " + service.addDoctor(n, p, s, f));
                    break;
                case 2: // VIEW ALL
                    System.out.println("\n--- ALL DOCTORS ---");
                    for(Doctor d : service.getAllDoctors()) System.out.println(d);
                    break;
                case 3: // SEARCH
                    scan.nextLine();
                    System.out.print("Doctor ID:");
                    System.out.println(service.findDoctor(scan.nextLine()));
                    break;
                case 4: return;
            }
        }
    }
    
    // APPOINTMENT MENU (Book, Cancel, View)
    private void appointmentMenu() throws HospitalException {
        while(true) {
            System.out.println("\n[APPOINTMENTS] 1.Book 2.Cancel 3.View 4.Back");
            System.out.print("Choice: ");
            switch(scan.nextInt()) {
                case 1: // BOOK APPOINTMENT
                    scan.nextLine();
                    System.out.print("Patient ID:"); String pid = scan.nextLine();
                    System.out.print("Doctor ID:"); String did = scan.nextLine();
                    System.out.print("Date & Time (2024-12-25 14:30):"); String dt = scan.nextLine();
                    System.out.println("✅ ID: " + service.bookAppointment(pid, did, dt));
                    break;
                case 2: // CANCEL APPOINTMENT
                    scan.nextLine();
                    System.out.print("Appointment ID:");
                    service.cancelAppointment(scan.nextLine());
                    System.out.println("✅ Cancelled!");
                    break;
                case 3: // VIEW PATIENT'S APPOINTMENTS
                    scan.nextLine();
                    System.out.print("Patient ID:");
                    String pid2 = scan.nextLine();
                    System.out.println("\n--- APPOINTMENTS ---");
                    for(Appointment a : service.getPatientAppointments(pid2)) 
                        System.out.println(a);
                    break;
                case 4: return;
            }
        }
    }
    
    // DISPLAY STATISTICS
    private void stats() {
        System.out.println("\n=== STATISTICS ===");
        System.out.println("Patients: " + service.getPatientCount());
        System.out.println("Doctors: " + service.getDoctorCount());
        System.out.println("Appointments: " + service.getAppointmentCount());
    }
}