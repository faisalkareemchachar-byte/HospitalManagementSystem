package service;

import model.*;
import exception.HospitalException;
import java.util.*;

public class HospitalService {
    private Map<String, Patient> patients = new HashMap<>();
    private Map<String, Doctor> doctors = new HashMap<>();
    private Map<String, Appointment> appointments = new HashMap<>();
    private int pCounter = 100, dCounter = 200, aCounter = 1000;
    
    public HospitalService() {
        doctors.put("DOC200", new Doctor("DOC200", "Dr. Smith", "555-0101", "Cardiology", 150));
        doctors.put("DOC201", new Doctor("DOC201", "Dr. Jones", "555-0102", "Neurology", 200));
        patients.put("PAT100", new Patient("PAT100", "Alice", "555-0201", "Flu"));
    }
    
    // Patient methods
    public String addPatient(String name, String phone, String disease) {
        String id = "PAT" + (++pCounter);
        patients.put(id, new Patient(id, name, phone, disease));
        return id;
    }
    
    public List<Patient> getAllPatients() { return new ArrayList<>(patients.values()); }
    
    public Patient findPatient(String id) throws HospitalException {
        if (!patients.containsKey(id)) throw new HospitalException("Patient not found!");
        return patients.get(id);
    }
    
    // Doctor methods
    public String addDoctor(String name, String phone, String spec, double fee) {
        String id = "DOC" + (++dCounter);
        doctors.put(id, new Doctor(id, name, phone, spec, fee));
        return id;
    }
    
    public List<Doctor> getAllDoctors() { return new ArrayList<>(doctors.values()); }
    
    public Doctor findDoctor(String id) throws HospitalException {
        if (!doctors.containsKey(id)) throw new HospitalException("Doctor not found!");
        return doctors.get(id);
    }
    
    // Appointment methods
    public String bookAppointment(String patientId, String doctorId, String datetime) throws HospitalException {
        findPatient(patientId);
        findDoctor(doctorId);
        String id = "APT" + (++aCounter);
        appointments.put(id, new Appointment(id, patientId, doctorId, datetime));
        return id;
    }
    
    public void cancelAppointment(String id) throws HospitalException {
        if (!appointments.containsKey(id)) throw new HospitalException("Appointment not found!");
        appointments.get(id).cancel();
    }
    
    public List<Appointment> getPatientAppointments(String patientId) throws HospitalException {
        findPatient(patientId);
        List<Appointment> result = new ArrayList<>();
        for (Appointment a : appointments.values()) {
            if (a.getPatientId().equals(patientId) && !a.getStatus().equals("CANCELLED"))
                result.add(a);
        }
        return result;
    }
    
    // Stats
    public int getPatientCount() { return patients.size(); }
    public int getDoctorCount() { return doctors.size(); }
    public int getAppointmentCount() { return appointments.size(); }
}