// src/Main.java
import ui.HospitalUI;

public class Main {
    public static void main(String[] args) {
        HospitalUI ui = new HospitalUI();
        ui.start();
    }
}